﻿namespace ConsoleServiceTool.Views
{
    interface IUserControl
    {
        string FriendlyName { get; }
    }
}
