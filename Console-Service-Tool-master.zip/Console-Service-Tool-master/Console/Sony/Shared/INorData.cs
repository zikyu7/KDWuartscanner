﻿namespace ConsoleServiceTool.Console.Sony.Shared
{
    internal interface INorData
    {
        byte[] ToArray();
    }
}
