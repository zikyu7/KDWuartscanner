﻿namespace ConsoleServiceTool.Console.Sony.Shared.Models
{
    public enum Priority
    {
        Low = 0, 
        Medium = 1,
        High = 2, 
        Severe = 3,
        Unknown = byte.MaxValue
    }
}
