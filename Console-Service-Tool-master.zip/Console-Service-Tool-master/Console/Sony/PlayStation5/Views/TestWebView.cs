﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConsoleServiceTool.Console.Sony.PlayStation5.Views
{
    public partial class TestWebView : UserControl
    {
        public TestWebView()
        {
            InitializeComponent();
        }
    }
}
