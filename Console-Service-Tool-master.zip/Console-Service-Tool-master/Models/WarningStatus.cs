﻿namespace ConsoleServiceTool.Models
{
    internal enum WarningStatus
    {
        Success,
        Error,
        Information,
        Unknown
    }
}
